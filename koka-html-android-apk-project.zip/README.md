# Koka HTML (com.koka.htmlplayer)

Нативное Android-приложение для запуска локальных `.html` файлов на полный экран без лишнего интерфейса (Immersive Sticky Fullscreen).

## Способ 1: Сборка готового .apk без установки программ (через GitHub за 2 минуты)
1. Создайте бесплатный репозиторий на GitHub и загрузите туда содержимое этого архива.
2. Перейдите во вкладку **Actions** → выберите **Build Fullscreen HTML APK** → нажмите **Run workflow**.
3. Через ~1.5 минуты скачайте готовый файл `app-debug.apk` в разделе **Artifacts** и установите на телефон!

## Способ 2: Сборка в Android Studio
1. Откройте папку проекта в Android Studio.
2. В верхнем меню выберите **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
