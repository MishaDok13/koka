package com.koka.htmlplayer

import android.annotation.SuppressLint
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Button
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import androidx.activity.ComponentActivity
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import java.io.BufferedReader
import java.io.InputStreamReader

class MainActivity : ComponentActivity() {

    private lateinit var rootLayout: FrameLayout
    private lateinit var launcherContainer: LinearLayout
    private lateinit var webView: WebView
    private var isShowingHtml = false

    private val openHtmlLauncher = registerForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri: Uri? ->
        if (uri != null) {
            try {
                contentResolver.takePersistableUriPermission(
                    uri,
                    Intent.FLAG_GRANT_READ_URI_PERMISSION
                )
            } catch (_: Exception) {}
            loadHtmlFromUri(uri)
        }
    }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        enablePureFullscreen()

        rootLayout = FrameLayout(this).apply {
            setBackgroundColor(Color.parseColor("#090D16"))
            layoutParams = ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
        }

        webView = WebView(this).apply {
            layoutParams = FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
            setBackgroundColor(Color.BLACK)
            visibility = View.GONE
            settings.apply {
                javaScriptEnabled = true
                domStorageEnabled = true
                databaseEnabled = true
                allowFileAccess = true
                allowContentAccess = true
                mediaPlaybackRequiresUserGesture = false
                loadWithOverviewMode = true
                useWideViewPort = true
                builtInZoomControls = false
                displayZoomControls = false
                cacheMode = WebSettings.LOAD_DEFAULT
            }
            webChromeClient = WebChromeClient()
            webViewClient = object : WebViewClient() {
                override fun shouldOverrideUrlLoading(
                    view: WebView?,
                    request: WebResourceRequest?
                ): Boolean = false
            }
        }

        launcherContainer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(64, 64, 64, 64)
            layoutParams = FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )

            val titleView = TextView(this@MainActivity).apply {
                text = "Koka HTML"
                textSize = 24f
                setTextColor(Color.parseColor("#F8FAFC"))
                gravity = Gravity.CENTER
            }

            val subtitleView = TextView(this@MainActivity).apply {
                text = "Выберите .html файл для запуска на полный экран без интерфейса"
                textSize = 14f
                setTextColor(Color.parseColor("#94A3B8"))
                gravity = Gravity.CENTER
                setPadding(0, 16, 0, 56)
            }

            val openBtn = Button(this@MainActivity).apply {
                text = "Открыть .html файл"
                textSize = 16f
                isAllCaps = false
                setBackgroundColor(Color.parseColor("#38BDF8"))
                setTextColor(Color.parseColor("#090D16"))
                setPadding(64, 36, 64, 36)
                setOnClickListener {
                    openHtmlLauncher.launch(arrayOf("text/html", "application/xhtml+xml", "*/*"))
                }
            }

            addView(titleView)
            addView(subtitleView)
            addView(openBtn)
        }

        rootLayout.addView(launcherContainer)
        rootLayout.addView(webView)
        setContentView(rootLayout)

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (isShowingHtml) {
                    if (webView.canGoBack()) {
                        webView.goBack()
                    } else if ("picker" == "picker") {
                        exitHtmlToLauncher()
                    } else {
                        finish()
                    }
                } else {
                    finish()
                }
            }
        })

        // Handle intent if user opened an .html file directly from Android File Manager
        if (intent?.data != null) {
            loadHtmlFromUri(intent.data!!)
        } else if ("picker" == "bundled") {
            showBundledAssetHtml()
        }
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) {
            enablePureFullscreen()
        }
    }

    private fun enablePureFullscreen() {
        WindowCompat.setDecorFitsSystemWindows(window, false)
        val controller = WindowInsetsControllerCompat(window, window.decorView)
        controller.hide(WindowInsetsCompat.Type.systemBars())
        controller.systemBarsBehavior =
            WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
    }

    private fun loadHtmlFromUri(uri: Uri) {
        try {
            val sb = StringBuilder()
            contentResolver.openInputStream(uri)?.use { inputStream ->
                BufferedReader(InputStreamReader(inputStream, Charsets.UTF_8)).use { reader ->
                    var line: String?
                    while (reader.readLine().also { line = it } != null) {
                        sb.append(line).append("\n")
                    }
                }
            }
            isShowingHtml = true
            launcherContainer.visibility = View.GONE
            webView.visibility = View.VISIBLE
            enablePureFullscreen()
            webView.loadDataWithBaseURL(
                "https://localhost/",
                sb.toString(),
                "text/html",
                "UTF-8",
                null
            )
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    private fun showBundledAssetHtml() {
        isShowingHtml = true
        launcherContainer.visibility = View.GONE
        webView.visibility = View.VISIBLE
        enablePureFullscreen()
        webView.loadUrl("file:///android_asset/index.html")
    }

    private fun exitHtmlToLauncher() {
        isShowingHtml = false
        webView.loadUrl("about:blank")
        webView.visibility = View.GONE
        launcherContainer.visibility = View.VISIBLE
    }
}
